"""
Docker provider for containerization and deployment management.
"""

import logging
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import docker
    from docker.errors import DockerException
except ImportError:
    docker = None
    DockerException = Exception

from . import Provider, register_provider

logger = logging.getLogger(__name__)


@register_provider
class DockerProvider(Provider):
    """Provider for Docker containerization and deployment."""

    @property
    def name(self) -> str:
        return "docker"

    def _configure(self) -> None:
        """Configure Docker provider."""
        try:
            if docker:
                self.client = docker.from_env()
                self.is_configured = True
            else:
                logger.warning("Docker package not installed")
        except Exception as e:
            logger.warning(f"Failed to connect to Docker daemon: {e}")

    def validate_connection(self) -> bool:
        """Validate Docker daemon connection."""
        if not self.is_configured:
            return False

        try:
            self.client.ping()
            return True
        except Exception as e:
            logger.error(f"Docker connection validation failed: {e}")
            return False

    def get_capabilities(self) -> List[str]:
        """Return Docker provider capabilities."""
        return [
            "build_image",
            "run_container",
            "manage_volumes",
            "compose_services",
            "security_scan",
            "registry_operations",
        ]

    def build_image(
        self,
        dockerfile_path: str,
        tag: str,
        build_context: str = ".",
        build_args: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Build Docker image from Dockerfile."""
        if not self.is_configured:
            raise RuntimeError("Docker provider not configured")

        try:
            build_logs = []

            image, logs = self.client.images.build(
                path=build_context,
                dockerfile=dockerfile_path,
                tag=tag,
                buildargs=build_args or {},
                rm=True,
                forcerm=True,
            )

            # Collect build logs
            for log in logs:
                if "stream" in log:
                    build_logs.append(log["stream"].strip())
                elif "error" in log:
                    build_logs.append(f"ERROR: {log['error']}")

            return {
                "image_id": image.id,
                "tags": image.tags,
                "size": image.attrs.get("Size", 0),
                "build_logs": build_logs,
                "success": True,
            }

        except DockerException as e:
            logger.error(f"Docker build failed: {e}")
            return {"success": False, "error": str(e), "build_logs": build_logs}

    def run_container(
        self,
        image: str,
        name: Optional[str] = None,
        ports: Optional[Dict[str, str]] = None,
        volumes: Optional[Dict[str, Dict[str, str]]] = None,
        environment: Optional[Dict[str, str]] = None,
        detach: bool = True,
    ) -> Dict[str, Any]:
        """Run Docker container from image."""
        if not self.is_configured:
            raise RuntimeError("Docker provider not configured")

        try:
            container = self.client.containers.run(
                image=image,
                name=name,
                ports=ports,
                volumes=volumes,
                environment=environment,
                detach=detach,
                remove=False,
            )

            return {
                "container_id": container.id,
                "name": container.name,
                "status": container.status,
                "ports": container.ports,
                "success": True,
            }

        except DockerException as e:
            logger.error(f"Container run failed: {e}")
            return {"success": False, "error": str(e)}

    def generate_dockerfile(self, config: Dict[str, Any]) -> str:
        """Generate optimized Dockerfile based on configuration."""
        python_version = config.get("python_version", "3.11")
        base_image = config.get("base_image", f"python:{python_version}-slim")
        package_name = config.get("package_name", "app")
        dependencies = config.get("dependencies", [])
        use_fastapi = config.get("use_fastapi", False)

        dockerfile_content = f"""# Multi-stage build for optimized production image
FROM {base_image} as builder

# Set environment variables
ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1
ENV PIP_NO_CACHE_DIR=1
ENV PIP_DISABLE_PIP_VERSION_CHECK=1

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    build-essential \\
    git \\
    && rm -rf /var/lib/apt/lists/*

# Create virtual environment
RUN python -m venv /opt/venv
ENV PATH="/opt/venv/bin:$PATH"

# Copy and install Python dependencies
COPY requirements*.txt ./
RUN pip install --upgrade pip setuptools wheel
RUN pip install -r requirements.txt
"""

        if dependencies:
            for dep in dependencies:
                dockerfile_content += f"RUN pip install {dep}\n"

        dockerfile_content += f"""
# Production stage
FROM {base_image} as production

# Set environment variables
ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1
ENV PATH="/opt/venv/bin:$PATH"

# Create non-root user
RUN groupadd -r appuser && useradd -r -g appuser appuser

# Copy virtual environment from builder stage
COPY --from=builder /opt/venv /opt/venv

# Set working directory
WORKDIR /app

# Copy application code
COPY --chown=appuser:appuser . .

# Install the package
RUN pip install -e .

# Switch to non-root user
USER appuser

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \\
    CMD python -c "import {package_name}; print('OK')" || exit 1
"""

        if use_fastapi:
            dockerfile_content += f"""
# Expose port for FastAPI
EXPOSE 8000

# Run FastAPI application
CMD ["uvicorn", "{package_name}.api.app:app", "--host", "0.0.0.0", "--port", "8000"]
"""
        else:
            dockerfile_content += f"""
# Default command
CMD ["python", "-m", "{package_name}"]
"""

        return dockerfile_content

    def generate_docker_compose(self, config: Dict[str, Any]) -> str:
        """Generate docker-compose.yml for multi-service setup."""
        package_name = config.get("package_name", "app")
        use_database = config.get("use_database", False)
        use_redis = config.get("use_redis", False)
        use_monitoring = config.get("use_monitoring", False)

        compose_content = f"""version: '3.8'

services:
  {package_name}:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: {package_name}
    restart: unless-stopped
    environment:
      - PYTHONPATH=/app
      - LOG_LEVEL=INFO
    volumes:
      - ./logs:/app/logs
    networks:
      - {package_name}_network
"""

        if use_database:
            compose_content += f"""    depends_on:
      - postgres
    environment:
      - DATABASE_URL=postgresql://postgres:password@postgres:5432/{package_name}
"""

        if config.get("use_fastapi", False):
            compose_content += """    ports:
      - "8000:8000"
"""

        if use_database:
            compose_content += f"""
  postgres:
    image: postgres:15-alpine
    container_name: {package_name}_postgres
    restart: unless-stopped
    environment:
      POSTGRES_DB: {package_name}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql
    networks:
      - {package_name}_network
    ports:
      - "5432:5432"
"""

        if use_redis:
            compose_content += f"""
  redis:
    image: redis:7-alpine
    container_name: {package_name}_redis
    restart: unless-stopped
    volumes:
      - redis_data:/data
    networks:
      - {package_name}_network
    ports:
      - "6379:6379"
"""

        if use_monitoring:
            compose_content += f"""
  prometheus:
    image: prom/prometheus:latest
    container_name: {package_name}_prometheus
    restart: unless-stopped
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    networks:
      - {package_name}_network
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana:latest
    container_name: {package_name}_grafana
    restart: unless-stopped
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana_data:/var/lib/grafana
    networks:
      - {package_name}_network
    ports:
      - "3000:3000"
"""

        # Add volumes section
        compose_content += f"""
volumes:"""

        if use_database:
            compose_content += """
  postgres_data:"""

        if use_redis:
            compose_content += """
  redis_data:"""

        if use_monitoring:
            compose_content += """
  prometheus_data:
  grafana_data:"""

        compose_content += f"""

networks:
  {package_name}_network:
    driver: bridge
"""

        return compose_content

    def security_scan_image(self, image_tag: str) -> Dict[str, Any]:
        """Perform security scan on Docker image."""
        if not self.is_configured:
            raise RuntimeError("Docker provider not configured")

        try:
            # Use docker scout or trivy for security scanning
            result = subprocess.run(
                ["docker", "scout", "cves", image_tag], capture_output=True, text=True, timeout=300
            )

            if result.returncode == 0:
                return {
                    "success": True,
                    "scan_output": result.stdout,
                    "vulnerabilities_found": "HIGH" in result.stdout or "CRITICAL" in result.stdout,
                }
            else:
                # Fallback to basic image inspection
                image = self.client.images.get(image_tag)
                return {
                    "success": True,
                    "scan_output": "Basic scan completed",
                    "image_info": {
                        "id": image.id,
                        "tags": image.tags,
                        "size": image.attrs.get("Size", 0),
                        "created": image.attrs.get("Created", "Unknown"),
                    },
                    "vulnerabilities_found": False,
                }

        except Exception as e:
            logger.error(f"Security scan failed: {e}")
            return {"success": False, "error": str(e)}

    def cleanup_resources(self, project_name: str) -> Dict[str, Any]:
        """Clean up Docker resources for a project."""
        if not self.is_configured:
            raise RuntimeError("Docker provider not configured")

        results = {
            "containers_removed": [],
            "images_removed": [],
            "volumes_removed": [],
            "networks_removed": [],
        }

        try:
            # Remove containers
            containers = self.client.containers.list(
                all=True, filters={"label": f"project={project_name}"}
            )
            for container in containers:
                container.remove(force=True)
                results["containers_removed"].append(container.name)

            # Remove images
            images = self.client.images.list(filters={"label": f"project={project_name}"})
            for image in images:
                self.client.images.remove(image.id, force=True)
                results["images_removed"].append(image.id[:12])

            # Remove volumes
            volumes = self.client.volumes.list(filters={"label": f"project={project_name}"})
            for volume in volumes:
                volume.remove(force=True)
                results["volumes_removed"].append(volume.name)

            return results

        except Exception as e:
            logger.error(f"Cleanup failed: {e}")
            results["error"] = str(e)
            return results
