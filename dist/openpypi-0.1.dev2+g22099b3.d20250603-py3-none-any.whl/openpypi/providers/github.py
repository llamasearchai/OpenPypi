"""
GitHub provider for repository management and CI/CD integration.
"""

import logging
import os
import subprocess
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:
    requests = None

from . import Provider, register_provider

logger = logging.getLogger(__name__)


@register_provider
class GitHubProvider(Provider):
    """Provider for GitHub repository management."""

    @property
    def name(self) -> str:
        return "github"

    def _configure(self) -> None:
        """Configure GitHub provider."""
        self.token = self.config.get("token") or os.getenv("GITHUB_TOKEN")
        self.username = self.config.get("username") or os.getenv("GITHUB_USERNAME")
        self.api_url = self.config.get("api_url", "https://api.github.com")

        if self.token:
            self.headers = {
                "Authorization": f"token {self.token}",
                "Accept": "application/vnd.github.v3+json",
            }
            self.is_configured = True
        else:
            logger.warning("GitHub token not configured")

    def validate_connection(self) -> bool:
        """Validate GitHub API connection."""
        if not self.is_configured or not requests:
            return False

        try:
            response = requests.get(f"{self.api_url}/user", headers=self.headers, timeout=10)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"GitHub connection validation failed: {e}")
            return False

    def get_capabilities(self) -> List[str]:
        """Return GitHub provider capabilities."""
        return [
            "create_repository",
            "setup_ci_cd",
            "manage_secrets",
            "create_releases",
            "manage_issues",
            "setup_webhooks",
        ]

    def create_repository(
        self, repo_name: str, description: str = "", private: bool = False
    ) -> Dict[str, Any]:
        """Create a new GitHub repository."""
        if not self.is_configured or not requests:
            raise RuntimeError("GitHub provider not configured")

        data = {
            "name": repo_name,
            "description": description,
            "private": private,
            "auto_init": True,
            "gitignore_template": "Python",
        }

        response = requests.post(
            f"{self.api_url}/user/repos", headers=self.headers, json=data, timeout=30
        )

        if response.status_code == 201:
            return response.json()
        else:
            raise RuntimeError(f"Failed to create repository: {response.text}")

    def setup_ci_cd(self, repo_name: str, workflow_content: str) -> bool:
        """Setup GitHub Actions workflow."""
        if not self.is_configured or not requests:
            raise RuntimeError("GitHub provider not configured")

        # Create .github/workflows directory and workflow file
        workflow_data = {"message": "Add CI/CD workflow", "content": workflow_content}

        url = f"{self.api_url}/repos/{self.username}/{repo_name}/contents/.github/workflows/ci.yml"
        response = requests.put(url, headers=self.headers, json=workflow_data, timeout=30)

        return response.status_code in [200, 201]

    def setup_repository_secrets(self, repo_name: str, secrets: Dict[str, str]) -> bool:
        """Setup repository secrets for CI/CD."""
        if not self.is_configured or not requests:
            raise RuntimeError("GitHub provider not configured")

        success = True
        for secret_name, secret_value in secrets.items():
            data = {"encrypted_value": secret_value}  # In practice, encrypt with repo public key

            url = f"{self.api_url}/repos/{self.username}/{repo_name}/actions/secrets/{secret_name}"
            response = requests.put(url, headers=self.headers, json=data, timeout=30)

            if response.status_code not in [201, 204]:
                logger.error(f"Failed to set secret {secret_name}")
                success = False

        return success

    def create_release(
        self, repo_name: str, tag_name: str, release_name: str, body: str = ""
    ) -> Dict[str, Any]:
        """Create a GitHub release."""
        if not self.is_configured or not requests:
            raise RuntimeError("GitHub provider not configured")

        data = {
            "tag_name": tag_name,
            "name": release_name,
            "body": body,
            "draft": False,
            "prerelease": False,
        }

        url = f"{self.api_url}/repos/{self.username}/{repo_name}/releases"
        response = requests.post(url, headers=self.headers, json=data, timeout=30)

        if response.status_code == 201:
            return response.json()
        else:
            raise RuntimeError(f"Failed to create release: {response.text}")

    def clone_repository(self, repo_url: str, local_path: str) -> bool:
        """Clone a repository locally."""
        try:
            cmd = ["git", "clone", repo_url, local_path]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            return result.returncode == 0
        except Exception as e:
            logger.error(f"Failed to clone repository: {e}")
            return False

    def push_to_repository(self, local_path: str, commit_message: str = "Initial commit") -> bool:
        """Push local changes to repository."""
        try:
            # Add all files
            subprocess.run(["git", "add", "."], cwd=local_path, check=True)

            # Commit changes
            subprocess.run(["git", "commit", "-m", commit_message], cwd=local_path, check=True)

            # Push to origin
            subprocess.run(["git", "push", "origin", "main"], cwd=local_path, check=True)

            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to push to repository: {e}")
            return False
