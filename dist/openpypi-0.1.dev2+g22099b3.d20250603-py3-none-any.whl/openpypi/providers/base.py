"""
Base provider interface with comprehensive functionality.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict

from ..core.exceptions import ProviderError
from ..utils.logger import get_logger

logger = get_logger(__name__)


class ProviderConfig(BaseModel):
    """Provider configuration model."""

    model_config = ConfigDict(extra="allow")

    name: str
    enabled: bool = True
    timeout: int = 30
    retry_attempts: int = 3
    configuration: Dict[str, Any] = {}


class BaseProvider(ABC):
    """
    Base provider class with comprehensive functionality.
    """

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.name = self.__class__.__name__.replace("Provider", "").lower()
        self.is_configured = self._check_configuration()
        self.timeout = self.config.get("timeout", 30)
        self.max_tokens = self.config.get("max_tokens", 2000)
        self.temperature = self.config.get("temperature", 0.7)
        self.model = self.config.get("model", "gpt-3.5-turbo")

    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Get provider capabilities."""
        pass

    @abstractmethod
    def validate_connection(self) -> bool:
        """Validate provider connection."""
        pass

    def _check_configuration(self) -> bool:
        """Check if provider is properly configured."""
        try:
            return self.validate_connection()
        except Exception:
            return False

    def get_info(self) -> Dict[str, Any]:
        """Get provider information."""
        return {
            "name": self.name,
            "configured": self.is_configured,
            "capabilities": self.get_capabilities(),
            "config": {k: v for k, v in self.config.items() if "key" not in k.lower()},
        }

    @abstractmethod
    async def generate_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Generate a response from the AI model.

        Args:
            prompt: User prompt
            system_prompt: System prompt for context
            temperature: Sampling temperature
            max_tokens: Maximum tokens in response
            **kwargs: Additional provider-specific parameters

        Returns:
            Response dictionary with content and metadata
        """
        pass

    @abstractmethod
    async def generate_code(
        self, specification: str, language: str = "python", **kwargs
    ) -> Dict[str, Any]:
        """
        Generate code based on specification.

        Args:
            specification: Code specification
            language: Programming language
            **kwargs: Additional parameters

        Returns:
            Generated code and metadata
        """
        pass

    @abstractmethod
    async def estimate_cost(self, text: str) -> Dict[str, float]:
        """
        Estimate the cost of processing given text.

        Args:
            text: Text to estimate cost for

        Returns:
            Cost estimation dictionary
        """
        pass

    @abstractmethod
    async def get_model_info(self) -> Dict[str, Any]:
        """Get information about the current model."""
        pass
