"""
Provider system for external integrations and services.

This module provides a pluggable architecture for integrating with external
services like GitHub, Docker, cloud providers, databases, and AI services.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type

logger = logging.getLogger(__name__)


class Provider(ABC):
    """Base class for all providers."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.is_configured = False
        self._configure()

    @abstractmethod
    def _configure(self) -> None:
        """Configure the provider with necessary settings."""
        pass

    @abstractmethod
    def validate_connection(self) -> bool:
        """Validate that the provider can connect to its service."""
        pass

    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Return list of capabilities this provider supports."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the provider name."""
        pass


class ProviderRegistry:
    """Registry for managing providers."""

    def __init__(self):
        self._providers: Dict[str, Type[Provider]] = {}
        self._instances: Dict[str, Provider] = {}

    def register(self, provider_class: Type[Provider]) -> None:
        """Register a provider class."""
        provider_name = provider_class.__name__.lower().replace("provider", "")
        self._providers[provider_name] = provider_class
        logger.info(f"Registered provider: {provider_name}")

    def get_provider(self, name: str, config: Optional[Dict[str, Any]] = None) -> Provider:
        """Get a provider instance by name."""
        if name not in self._providers:
            raise ValueError(f"Unknown provider: {name}")

        if name not in self._instances:
            self._instances[name] = self._providers[name](config)

        return self._instances[name]

    def list_providers(self) -> List[str]:
        """List all registered providers."""
        return list(self._providers.keys())

    def get_capabilities(self, name: str) -> List[str]:
        """Get capabilities of a specific provider."""
        provider = self.get_provider(name)
        return provider.get_capabilities()


# Global provider registry
registry = ProviderRegistry()


def register_provider(provider_class: Type[Provider]) -> Type[Provider]:
    """Decorator to register a provider."""
    registry.register(provider_class)
    return provider_class


from .ai import AIProvider, OpenAIProvider
from .cloud import CloudProvider
from .database import DatabaseProvider
from .docker import DockerProvider

# Import and register built-in providers
from .github import GitHubProvider


def get_provider(name: str, config: Optional[Dict[str, Any]] = None) -> Provider:
    """Get a provider instance by name from the global registry."""
    return registry.get_provider(name, config)


def list_providers() -> List[str]:
    """List all registered providers."""
    return registry.list_providers()


__all__ = [
    "Provider",
    "ProviderRegistry",
    "registry",
    "register_provider",
    "get_provider",
    "list_providers",
    "GitHubProvider",
    "DockerProvider",
    "CloudProvider",
    "AIProvider",
    "OpenAIProvider",
    "DatabaseProvider",
]
