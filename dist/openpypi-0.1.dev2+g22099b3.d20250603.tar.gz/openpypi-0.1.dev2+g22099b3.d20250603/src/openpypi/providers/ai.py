"""
AI provider for OpenAI Agents SDK integration and advanced AI capabilities.
"""

import asyncio
import logging
import os
from typing import Any, Dict, List, Optional, Union

try:
    from openai import AsyncOpenAI, OpenAI
    from openai.types.chat import ChatCompletion
except ImportError:
    OpenAI = None
    AsyncOpenAI = None
    ChatCompletion = None

from . import Provider, register_provider

logger = logging.getLogger(__name__)


@register_provider
class AIProvider(Provider):
    """Provider for AI services and agent orchestration."""

    @property
    def name(self) -> str:
        return "ai"

    def _configure(self) -> None:
        """Configure AI provider."""
        self.api_key = self.config.get("api_key") or os.getenv("OPENAI_API_KEY")
        self.model = self.config.get("model", "gpt-3.5-turbo")
        self.max_tokens = self.config.get("max_tokens", 2048)
        self.temperature = self.config.get("temperature", 0.7)

        if self.api_key and OpenAI:
            self.client = OpenAI(api_key=self.api_key)
            self.async_client = AsyncOpenAI(api_key=self.api_key)
            self.is_configured = True
        else:
            logger.warning("OpenAI API key not configured or openai package not installed")
            self.is_configured = False

    def validate_connection(self) -> bool:
        """Validate AI provider connection."""
        if not self.is_configured:
            return False

        try:
            # Simple test to validate connection
            response = self.client.chat.completions.create(
                model=self.model, messages=[{"role": "user", "content": "test"}], max_tokens=5
            )
            return bool(response.choices)
        except Exception as e:
            logger.error(f"AI provider connection validation failed: {e}")
            return False

    def get_capabilities(self) -> List[str]:
        """Return AI provider capabilities."""
        return [
            "text_generation",
            "code_generation",
            "code_review",
            "test_generation",
            "documentation",
            "analysis",
        ]

    def generate_code(self, prompt: str, language: str = "python") -> str:
        """Generate code using AI."""
        if not self.is_configured:
            raise RuntimeError("AI provider not configured")

        system_prompt = f"""You are an expert {language} developer. Generate clean, 
        production-ready code that follows best practices. Include proper error handling,
        type hints, docstrings, and comments where appropriate."""

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            max_tokens=self.max_tokens,
            temperature=self.temperature,
        )

        return response.choices[0].message.content

    def review_code(self, code: str, language: str = "python") -> Dict[str, Any]:
        """Review code for quality, security, and best practices."""
        if not self.is_configured:
            raise RuntimeError("AI provider not configured")

        system_prompt = f"""You are a senior code reviewer. Analyze the provided {language} 
        code for:
        1. Code quality and best practices
        2. Security vulnerabilities
        3. Performance issues
        4. Maintainability concerns
        5. Testing coverage gaps
        
        Provide specific recommendations for improvement."""

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Review this code:\n\n{code}"},
            ],
            max_tokens=self.max_tokens,
            temperature=0.3,
        )

        review_content = response.choices[0].message.content

        return {
            "review": review_content,
            "recommendations": self._extract_recommendations(review_content),
            "severity": self._assess_severity(review_content),
        }

    def generate_tests(self, code: str, test_framework: str = "pytest") -> str:
        """Generate comprehensive tests for given code."""
        if not self.is_configured:
            raise RuntimeError("AI provider not configured")

        system_prompt = f"""You are a test automation expert. Generate comprehensive 
        {test_framework} tests for the provided code. Include:
        1. Unit tests for all functions/methods
        2. Edge case testing
        3. Error condition testing
        4. Mock usage where appropriate
        5. Parametrized tests for multiple scenarios
        
        Ensure 100% code coverage and follow testing best practices."""

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Generate tests for this code:\n\n{code}"},
            ],
            max_tokens=self.max_tokens,
            temperature=0.5,
        )

        return response.choices[0].message.content

    def generate_documentation(self, code: str, doc_format: str = "sphinx") -> str:
        """Generate comprehensive documentation for code."""
        if not self.is_configured:
            raise RuntimeError("AI provider not configured")

        system_prompt = f"""You are a technical documentation expert. Generate 
        comprehensive {doc_format} documentation for the provided code. Include:
        1. Module/class/function descriptions
        2. Parameter and return value documentation
        3. Usage examples
        4. Code samples
        5. Installation and setup instructions
        
        Follow documentation best practices and standards."""

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Document this code:\n\n{code}"},
            ],
            max_tokens=self.max_tokens,
            temperature=0.4,
        )

        return response.choices[0].message.content

    def analyze_architecture(self, project_structure: str) -> Dict[str, Any]:
        """Analyze project architecture and suggest improvements."""
        if not self.is_configured:
            raise RuntimeError("AI provider not configured")

        system_prompt = """You are a software architecture expert. Analyze the provided 
        project structure and suggest improvements for:
        1. Architectural patterns and principles
        2. Module organization and dependencies
        3. Scalability considerations
        4. Security architecture
        5. Performance optimizations
        6. Maintainability improvements"""

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": f"Analyze this project structure:\n\n{project_structure}",
                },
            ],
            max_tokens=self.max_tokens,
            temperature=0.6,
        )

        analysis = response.choices[0].message.content

        return {
            "analysis": analysis,
            "recommendations": self._extract_recommendations(analysis),
            "priority": self._assess_priority(analysis),
        }

    async def generate_code_async(self, prompt: str, language: str = "python") -> str:
        """Generate code asynchronously."""
        if not self.is_configured:
            raise RuntimeError("AI provider not configured")

        system_prompt = f"""You are an expert {language} developer. Generate clean, 
        production-ready code that follows best practices."""

        response = await self.async_client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            max_tokens=self.max_tokens,
            temperature=self.temperature,
        )

        return response.choices[0].message.content

    def create_agent_workflow(self, task_description: str) -> Dict[str, Any]:
        """Create an agent workflow for complex tasks."""
        if not self.is_configured:
            raise RuntimeError("AI provider not configured")

        system_prompt = """You are an AI agent orchestration expert. Design a workflow 
        for the given task that breaks it down into:
        1. Sequential steps
        2. Required tools/capabilities
        3. Success criteria
        4. Error handling strategies
        5. Quality checkpoints
        
        Return a structured workflow plan."""

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Create a workflow for: {task_description}"},
            ],
            max_tokens=self.max_tokens,
            temperature=0.5,
        )

        workflow_content = response.choices[0].message.content

        return {
            "workflow": workflow_content,
            "steps": self._extract_workflow_steps(workflow_content),
            "tools_required": self._extract_tools_required(workflow_content),
        }

    def _extract_recommendations(self, content: str) -> List[str]:
        """Extract actionable recommendations from AI response."""
        # Simple extraction logic - can be enhanced with NLP
        lines = content.split("\n")
        recommendations = []

        for line in lines:
            line = line.strip()
            if line.startswith(("- ", "• ", "1. ", "2. ", "3. ")) or "recommend" in line.lower():
                recommendations.append(line)

        return recommendations[:10]  # Limit to top 10

    def _assess_severity(self, content: str) -> str:
        """Assess severity of issues found in code review."""
        content_lower = content.lower()

        if any(
            word in content_lower for word in ["critical", "security", "vulnerability", "dangerous"]
        ):
            return "HIGH"
        elif any(word in content_lower for word in ["warning", "issue", "problem", "concern"]):
            return "MEDIUM"
        else:
            return "LOW"

    def _assess_priority(self, content: str) -> str:
        """Assess priority of architectural recommendations."""
        content_lower = content.lower()

        if any(word in content_lower for word in ["urgent", "critical", "immediate", "breaking"]):
            return "HIGH"
        elif any(word in content_lower for word in ["important", "significant", "major"]):
            return "MEDIUM"
        else:
            return "LOW"

    def _extract_workflow_steps(self, content: str) -> List[str]:
        """Extract workflow steps from AI response."""
        # Simple extraction logic
        lines = content.split("\n")
        steps = []

        for line in lines:
            line = line.strip()
            if line.startswith(("Step ", "step ", "1. ", "2. ", "3. ", "4. ", "5. ")):
                steps.append(line)

        return steps

    def _extract_tools_required(self, content: str) -> List[str]:
        """Extract required tools from workflow content."""
        # Simple extraction logic
        content_lower = content.lower()
        common_tools = [
            "git",
            "docker",
            "kubernetes",
            "pytest",
            "black",
            "mypy",
            "github",
            "gitlab",
            "jenkins",
            "terraform",
            "ansible",
        ]

        tools_found = []
        for tool in common_tools:
            if tool in content_lower:
                tools_found.append(tool)

        return tools_found


@register_provider
class OpenAIProvider(AIProvider):
    """OpenAI specific provider with enhanced capabilities."""

    @property
    def name(self) -> str:
        return "openai"

    def _configure(self) -> None:
        """Configure OpenAI provider with enhanced settings."""
        self.api_key = self.config.get("api_key") or os.getenv("OPENAI_API_KEY")
        self.model = self.config.get("model", "gpt-4")
        self.max_tokens = self.config.get("max_tokens", 4096)
        self.temperature = self.config.get("temperature", 0.7)

        if self.api_key and OpenAI:
            self.client = OpenAI(api_key=self.api_key)
            self.async_client = AsyncOpenAI(api_key=self.api_key)
            self.is_configured = True
        else:
            logger.warning("OpenAI API key not configured or openai package not installed")
            self.is_configured = False

    def get_capabilities(self) -> List[str]:
        """Return enhanced OpenAI provider capabilities."""
        return [
            "code_generation",
            "code_review",
            "test_generation",
            "documentation_generation",
            "architecture_analysis",
            "security_scanning",
            "performance_optimization",
            "agent_orchestration",
        ]
