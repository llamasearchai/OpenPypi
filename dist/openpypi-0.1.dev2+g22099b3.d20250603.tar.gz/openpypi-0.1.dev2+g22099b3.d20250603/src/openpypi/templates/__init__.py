"""
Template management system for OpenPypi.
"""

from openpypi.templates.base import Template, TemplateManager

__all__ = ["Template", "TemplateManager"]
